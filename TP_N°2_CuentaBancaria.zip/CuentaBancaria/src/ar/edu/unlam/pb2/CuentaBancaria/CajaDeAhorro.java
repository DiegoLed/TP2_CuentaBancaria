package ar.edu.unlam.pb2.CuentaBancaria;

public class CajaDeAhorro extends CuentaBancaria {
	
	private Double costoAdicionalExtraccion = 6.0;
	private Integer cantidadDeExtraccionesParaCostoAdicional = 5;
	
	public CajaDeAhorro () {
		super();
	}
	
	public void extraer(Double montoExtraer) throws RuntimeException {
		
		Double dineroExtraer = montoExtraer;
		if ((this.getCantidadDeExtracciones()+1) % this.cantidadDeExtraccionesParaCostoAdicional == 0){
			dineroExtraer += this.costoAdicionalExtraccion;
		}
		
		Double saldoActual = this.getSaldo();
		if(saldoActual >= dineroExtraer){
			
			this.setSaldo(saldoActual - dineroExtraer);
			
			Integer cantidadActualExtracciones = this.getCantidadDeExtracciones();
			this.setCantidadDeExtracciones(cantidadActualExtracciones +1);
		}
		else 
			{ 
				throw new RuntimeException();
			}
	}

}
