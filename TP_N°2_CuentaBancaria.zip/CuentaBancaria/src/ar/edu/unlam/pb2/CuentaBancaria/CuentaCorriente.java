package ar.edu.unlam.pb2.CuentaBancaria;

public class CuentaCorriente extends CuentaBancaria{
	
	private Double comisionPorExtraerGiroDescubierto = 0.05;
	private Double giroPermitidoEnDescubierto = 150.0;
	


	public CuentaCorriente() {
		super();
	}

	public Double getComisionPorExtraerGiroDescubierto() {
		return comisionPorExtraerGiroDescubierto;
	}

	public Double getGiroPermitidoEnDescubierto() {
		return giroPermitidoEnDescubierto;
	}
	
	public void extraer(Double montoExtraer) throws RuntimeException {
		Double dineroExtraer = montoExtraer;
		Double saldoActual = this.getSaldo();
		Double giroPermitidoEnDescubierto = this.getGiroPermitidoEnDescubierto();
		
		if (saldoActual >=dineroExtraer){
			this.setSaldo(saldoActual - dineroExtraer);
		} else if ((saldoActual + giroPermitidoEnDescubierto) >= dineroExtraer)	{
			Double comisionADescontar = (dineroExtraer - saldoActual) * comisionPorExtraerGiroDescubierto;
			
			this.setSaldo(saldoActual - dineroExtraer - comisionADescontar);
		} 
			else {
					throw new RuntimeException();
				}
			
	}
	
	
	

}
