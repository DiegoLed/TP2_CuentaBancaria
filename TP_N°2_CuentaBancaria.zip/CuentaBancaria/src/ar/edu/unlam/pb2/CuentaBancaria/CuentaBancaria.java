package ar.edu.unlam.pb2.CuentaBancaria;

public class CuentaBancaria {
	private Double saldo;
	private Integer cantidadDeExtracciones;
	
	public CuentaBancaria (){
		
		this.saldo = 0.0;
		this.cantidadDeExtracciones = 0;
	}
	
	public void depositar (Double montoADepositar){
		Double saldoActual = this.getSaldo();
		this.setSaldo(saldoActual + montoADepositar);
		
	}

	protected Double getSaldo() {
		// TODO Auto-generated method stub
		return saldo;
	}
	
	protected void setSaldo(Double saldo) {
		this.saldo = saldo;
		
	}

	public Integer getCantidadDeExtracciones() {
		return cantidadDeExtracciones;
	}

	public void setCantidadDeExtracciones(Integer cantidadDeExtracciones) {
		this.cantidadDeExtracciones = cantidadDeExtracciones;
	}
	
}
