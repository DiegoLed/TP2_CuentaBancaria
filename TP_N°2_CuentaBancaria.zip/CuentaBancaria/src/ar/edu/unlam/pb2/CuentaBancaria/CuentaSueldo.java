package ar.edu.unlam.pb2.CuentaBancaria;

public class CuentaSueldo extends CuentaBancaria {
	
	public CuentaSueldo () {
		super();
	} 

	public void extraer (Double montoExtraer) throws RuntimeException {
		Double saldo = this.getSaldo();
		
		if (saldo >= montoExtraer) {
			double saldoActual = saldo - montoExtraer;
			this.setSaldo(saldoActual);

		} else { 
			throw new RuntimeException();
			}
	}
	
}

