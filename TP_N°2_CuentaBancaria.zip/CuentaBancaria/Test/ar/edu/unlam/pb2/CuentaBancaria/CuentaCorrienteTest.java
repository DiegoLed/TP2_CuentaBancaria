package ar.edu.unlam.pb2.CuentaBancaria;

import org.junit.Assert;
import org.junit.Test;

public class CuentaCorrienteTest {
	
	@Test
	
	public void extraer(){
		CuentaCorriente miCuentaCorriente = new CuentaCorriente();
		miCuentaCorriente.depositar(100.00);
		
		miCuentaCorriente.extraer(200.00);
		Double saldo = miCuentaCorriente.getSaldo();
		Double saldoEsperado = (100 - 200) * 1.05;
		
		Assert.assertEquals(saldoEsperado, saldo);		
	}

	@Test
	
	public void siSaldoSolicitadoEsInsuficiente() {
		CuentaCorriente miCuentaCorriente = new CuentaCorriente();
		miCuentaCorriente.depositar(100.00);
		
		boolean saldoInsuficiente = false;
		try {
			miCuentaCorriente.extraer(4000.0);
		} catch (RuntimeException e) {
			saldoInsuficiente = true;
		}
		Assert.assertEquals(true, saldoInsuficiente);
	}
}
