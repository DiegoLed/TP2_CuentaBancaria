package ar.edu.unlam.pb2.CuentaBancaria;

import org.junit.Assert;
import org.junit.Test;

public class CuentaBancariaTest {

	@Test
	
	public void depositar () {
		CuentaBancaria miCuentaBancaria = new CuentaBancaria();
		Double saldoEsperado = 4000.00;
		miCuentaBancaria.depositar(4000.00);
		
		
		Double saldo = miCuentaBancaria.getSaldo();
		Assert.assertEquals(saldoEsperado, saldo);
	}
}
