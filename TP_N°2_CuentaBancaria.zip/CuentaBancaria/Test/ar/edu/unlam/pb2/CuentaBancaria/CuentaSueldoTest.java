package ar.edu.unlam.pb2.CuentaBancaria;

import org.junit.Assert;
import org.junit.Test;

public class CuentaSueldoTest {
	
	@Test
	public void extraer(){
		CuentaSueldo miCuentaSueldo = new CuentaSueldo();
		miCuentaSueldo.depositar(4000.00);
		
		miCuentaSueldo.extraer(500.00);
		Double saldo = miCuentaSueldo.getSaldo();
		Double saldoEsperado = 3500.00;
		
		Assert.assertEquals(saldoEsperado, saldo);
		
	}
	@Test
	
	public void siSaldoSolicitadoEsInsuficiente() {
		CuentaSueldo miCuentaSueldo = new CuentaSueldo();
		miCuentaSueldo.depositar(100.00);
		
		boolean saldoInsuficiente = false;
		try {
			miCuentaSueldo.extraer(4000.0);
		} catch (RuntimeException e) {
			saldoInsuficiente = true;
		}
		Assert.assertEquals(true, saldoInsuficiente);
	}
	
}
