package ar.edu.unlam.pb2.CuentaBancaria;

import org.junit.Assert;
import org.junit.Test;

public class CajaDeAhorroTest {

	@Test 
	
	public void extraer (){
		CajaDeAhorro miCajaDeAhorro = new CajaDeAhorro();
		miCajaDeAhorro.depositar(4000.00);
		
		miCajaDeAhorro.extraer(500.00);
		
		Double saldo = miCajaDeAhorro.getSaldo();
		Double saldoEsperado = 3500.00;
		Assert.assertEquals(saldoEsperado, saldo);
		
		miCajaDeAhorro.extraer(100.00);
		miCajaDeAhorro.extraer(100.00);
		miCajaDeAhorro.extraer(100.00);
		miCajaDeAhorro.extraer(100.00); // 5ta extraccion
		
		saldo = miCajaDeAhorro.getSaldo();
		Double saldoEsperadoConCincoExtracciones = 3094.00;
		Assert.assertEquals(saldoEsperadoConCincoExtracciones, saldo);
	}
	
	@Test
	
	public void siSaldoSolicitadoEsInsuficiente() {
		CajaDeAhorro miCajaDeAhorro = new CajaDeAhorro();
		miCajaDeAhorro.depositar(100.00);
		
		boolean saldoInsuficiente = false;
		try {
			miCajaDeAhorro.extraer(4000.0);
		} catch (RuntimeException e) {
			saldoInsuficiente = true;
		}
		Assert.assertEquals(true, saldoInsuficiente);
	}
}
